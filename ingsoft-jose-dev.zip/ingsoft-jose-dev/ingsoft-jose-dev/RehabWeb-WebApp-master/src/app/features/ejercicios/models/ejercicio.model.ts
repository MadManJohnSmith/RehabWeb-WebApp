import { ValidacionEjercicio } from './validacion.model';

export type EstadoPublicacion = 'BORRADOR' | 'PENDIENTE_VALIDACION' | 'PUBLICADO';

export interface Ejercicio {
  id: string;
  nombre: string;
  descripcion: string;
  /** Campos legacy / UI; el API Django puede omitirlos */
  instrucciones?: string;
  material_necesario?: string;
  video_url?: string;
  /** Alias del campo `url_video` del API (mismo valor que `video_url`). */
  url_video?: string;
  imagen_url?: string;
  categoria?: string;
  dificultad?: 'FACIL' | 'INTERMEDIO' | 'DIFICIL';
  estado: EstadoPublicacion;
  estado_publicacion?: EstadoPublicacion;
  evidencia_cientifica?: string;
  es_personalizado?: boolean;
  autor_id?: string;
  /** Nombre del usuario creador (API Django `creador_nombre`). */
  creador_nombre?: string;
  puntuacion_media?: number;
  total_valoraciones?: number;
  series?: number;
  reps?: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
  historial_validaciones?: ValidacionEjercicio[];
}

export interface EjercicioFormData {
  nombre: string;
  descripcion: string;
  instrucciones: string;
  material_necesario: string;
  video_url?: string;
  imagen_url?: string;
  categoria: string;
  dificultad: 'FACIL' | 'INTERMEDIO' | 'DIFICIL';
  evidencia_cientifica?: string;
  estado?: EstadoPublicacion;
}
