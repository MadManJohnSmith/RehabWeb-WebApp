import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, catchError, of, throwError } from 'rxjs';
import { API_BASE_URL, withApiBase } from '../../../core/http/api-base-url';
import {
  MOCK_PACIENTES,
  mockPacienteDetalle,
} from '../../../core/mock/clinical-mock.data';

export interface PacienteListItem {
  paciente_id: string;
  nombre_completo: string;
  email: string;
  estado: string;
}

export interface PerfilClinicoDto {
  id: string;
  diagnostico_principal: string;
  historial_medico: string;
  nivel_movilidad: string;
  restricciones: string;
  territorio_acv: string | null;
}

export interface EvaluacionPrioritariaDto {
  id: string;
  fecha_evaluacion: string;
  notas_evaluacion: string;
  metricas_objetivas: Record<string, unknown>;
  es_evaluacion_inicial: boolean;
  terapeuta_evaluador: string;
}

export interface PacienteDetalleDto extends PacienteListItem {
  fecha_nacimiento: string | null;
  perfil_clinico: PerfilClinicoDto | null;
  evaluacion_prioritaria: EvaluacionPrioritariaDto | null;
}

@Injectable({
  providedIn: 'root',
})
export class PacienteService {
  private readonly http = inject(HttpClient);
  private readonly apiBase = inject(API_BASE_URL);
  private readonly baseUrl = withApiBase(this.apiBase, '/api/pacientes');

  listar(): Observable<PacienteListItem[]> {
    return this.http.get<PacienteListItem[]>(`${this.baseUrl}/`).pipe(
      catchError((err) => {
        console.warn('[PacienteService] API no disponible, usando datos mock', err);
        return of([...MOCK_PACIENTES]);
      }),
    );
  }

  obtenerDetalle(pacienteId: string): Observable<PacienteDetalleDto> {
    return this.http.get<PacienteDetalleDto>(`${this.baseUrl}/${pacienteId}/`).pipe(
      catchError((err) => {
        const mock = mockPacienteDetalle(pacienteId);
        if (mock) {
          console.warn('[PacienteService] detalle mock para', pacienteId);
          return of(mock);
        }
        console.error('[PacienteService] detalle no encontrado', err);
        return throwError(() => err);
      }),
    );
  }
}
